package com.itheima.demo01.WaitAndNotify;
/*
    资源类:包子类
	设置包子的属性
		皮
		陷
		包子的状态: 有 true,没有 false
 */
public class BaoZi {
    //皮
    String pi;
    //陷
    String xian;
    //包子的状态: 有 true,没有 false,设置初始值为false没有包子
    boolean flag = false;

}
