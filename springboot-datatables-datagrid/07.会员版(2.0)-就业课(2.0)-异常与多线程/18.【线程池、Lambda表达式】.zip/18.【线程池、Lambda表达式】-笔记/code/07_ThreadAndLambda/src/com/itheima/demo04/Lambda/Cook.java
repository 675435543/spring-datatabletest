package com.itheima.demo04.Lambda;
/*
    定一个厨子Cook接口，内含唯一的抽象方法makeFood
 */
public interface Cook {
    //定义无参数无返回值的方法makeFood
    public abstract void makeFood();
}
